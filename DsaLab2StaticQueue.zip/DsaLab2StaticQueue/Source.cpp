#include "Header.h";
int main()
{
	StaticQueue <int> s1(3);
	s1.push(4);
	s1.push(44);
	//s1.push(41);
	s1.pop();
	//s1.pop();
	s1.push(99);
	s1.print();
}