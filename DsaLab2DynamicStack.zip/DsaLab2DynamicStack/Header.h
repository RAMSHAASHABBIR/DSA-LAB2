#pragma once
#include <iostream>
#include <stack>
#include <stdexcept>
#include <vector>
using namespace std;
template<typename T>
class Dynammicstack
{
private:
     vector <T> DS;
public:
	Dynammicstack()
	{
		vector <T> DS;
	}
	bool Empty()
	{
		return DS.size() == 0;
	}
	
	void push(T val)
	{
		DS.push_back(val);
		//DS.insert(DS.begin(), val);
		//DS.erase(DS.begin());
	}
	void pop()
	{
		if (Empty())
		{
			throw exception("STACK IS EMPTY");
		}
		DS.pop();
	}
	T top()
	{
		if (Empty())
		{
			throw exception("STACK IS EMPTY");
		}
		return DS[DS.size() - 1];
	}
	T Size()
	{
		return DS.size();
	}
	void print()
	{
		for (int i = 0;i < DS.size();i++)
		{
			cout << DS[i] << endl;
		}
	}
};
