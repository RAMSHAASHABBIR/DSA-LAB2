#include "Header.h";
int main()
{
	DynamicQueue <int> s1;
	s1.push(4);
	s1.push(41);
	s1.push(42);
	s1.push(43);
	s1.pop();
	s1.pop();
	s1.push(99);
	s1.push(56);
	s1.print();
}