#include "Header.h";
int main()
{
	StaicStack <int> s1(10);
	s1.push(3);
	s1.push(4);
	s1.push(5);
	s1.push(6);
	s1.print();
	//s1.pop();
	//s1.pop();
	//s1.pop();
	//s1.pop();
	s1.Empty();
	//s1.print();
	try
	{
		int s = s1.top();
		cout << s << endl;
	}
	catch (exception e)
	{
		cout << e.what() << endl;
	}
	int size = s1.Size();
	cout << size << endl;

}