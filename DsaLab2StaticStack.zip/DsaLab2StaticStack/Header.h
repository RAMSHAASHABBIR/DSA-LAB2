#pragma once
#include <iostream>
#include <stack>
#include <stdexcept>
using namespace std;
template<typename T>
class StaicStack
{
private:
	int capacity;
	int size;
	T* SS;
public:
	StaicStack(int cap)
	{
		size = 0;
		capacity = cap;
		SS = new T[capacity];
	}
	bool Empty()
	{
		return size == 0;
	}
	void push(T val)
	{
		if (size == capacity)
		{
			throw exception("STACK IS FULL");
		}
		SS[size] = val;
		size++;
	}
	void pop()
	{
		if (Empty())
		{
			throw exception("STACK IS EMPTY");
		}
		size--;
	}
	T top()
	{

		if (Empty())
		{
			throw exception("STACK IS EMPTY");
		}
		return SS[size - 1];
	}
    T Size()
	{
		return size;
	}
	void print()
	{
		for (int i=0;i<size;i++)
		{
			cout << SS[i] << endl;
		}
	}
};
